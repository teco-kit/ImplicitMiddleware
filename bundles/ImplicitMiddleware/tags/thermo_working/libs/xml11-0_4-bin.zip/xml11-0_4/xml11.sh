#!/bin/sh

if [ "$JAVA_HOME"a == a ]; then 
	echo Please set JAVA_HOME to a valid JRE installation
	echo If you are using cygwin set it like this:
    echo '   export JAVA_HOME=C:/Programme/... instead of'
	echo '   export JAVA_HOME=/cygdrive/c/Programme/...'
	exit
fi

echo
echo Starting XML11 using SimpleWeb gateway. 
echo Visit http://localhost:8080/demo for a list of demos.

# First set CLASSPATH delimiters to ; (in case of cygwin)
CLASSPATH="jar\xml11-core.jar;jar\awtPlugin.jar;lib\xmlvm.jar;lib\xmlob.jar;lib\simple.jar;lib\jdom.jar;lib\log4j.jar;lib\bcel.jar;lib\jakarta-regexp.jar;lib\jsolait.zip;$RT_JAR;$JCE_JAR;$JSSE_JAR;$RSASIGN_JAR"
DEMO_CLASSPATH="jar\demo.jar;demo\lib\weirdx.jar;."
CLASSPATH="$CLASSPATH;$DEMO_CLASSPATH"
TOOLKIT=org.xml11.awt.XML11Toolkit
START_CLASS=org.xml11.gw.XML11Server
XML11_JVM_OPTS="-DconfigPath=./appConfig -DpluginPath=./plugins -DXML11_ROOT=./"
#DEBUG="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,address=8000,suspend=n"

# if not cygwin replace ; delimiters with :
# and \ delimiter with /
if [ `echo $OS | grep -i windows`a == a ]; then
	CLASSPATH=`echo $CLASSPATH | sed s/\;/:/g`
	CLASSPATH=`echo $CLASSPATH | sed 's/\\\/\\//g'`
#	BOOT_CLASSPATH="`echo $BOOT_CLASSPATH | sed s/\;/:/g`"
#	BOOT_CLASSPATH="`echo $BOOT_CLASSPATH | sed 's/\\\/\\//g'`"
fi

"$JAVA_HOME/bin/java" $DEBUG -classpath $CLASSPATH -Dawt.toolkit=$TOOLKIT $XML11_JVM_OPTS $START_CLASS
